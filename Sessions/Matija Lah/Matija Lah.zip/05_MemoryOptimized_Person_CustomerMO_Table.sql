-- 05_MemoryOptimized_Person_CustomerMO_Table
if	(object_id('Person.CustomerMO') is not null)
	begin
		drop table	Person.CustomerMO
	end
go

create table	Person.CustomerMO
	(
	BusinessEntityID		int								not null
	,PersonType			nchar(2)							not null
	,NameStyle			bit								not null
	,Title				nvarchar(8)							null
	,FirstName			nvarchar(50)							not null
	,MiddleName			nvarchar(50)							null
	,LastName			nvarchar(50)							not null
	,Suffix				nvarchar(10)							null
	,EmailPromotion			int								not null
	,AdditionalContactInfo		varbinary(4000)							null
	,Demographics			varbinary(2000)							null
	,rowguid			uniqueidentifier						not null
	,ModifiedDate			datetime							not null
	,CustomerID			int								not null
	,primary key nonclustered hash
		(
		CustomerID
		)
		with	(
			bucket_count = 131072
			)
	)
	with	(
		memory_optimized = on
		,durability = schema_and_data
		)
go

insert	Person.CustomerMO
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID as BusinessEntityID
		,Person.PersonType as PersonType
		,Person.NameStyle as NameStyle
		,Person.Title as Title
		,Person.FirstName as FirstName
		,Person.MiddleName as MiddleName
		,Person.LastName as LastName
		,Person.Suffix as Suffix
		,Person.EmailPromotion as EmailPromotion
		,cast(Person.AdditionalContactInfo as varbinary(4000)) as AdditionalContactInfo
		,cast(Person.Demographics as varbinary(2000)) as Demographics
		,Person.rowguid as rowguid
		,Person.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
go
