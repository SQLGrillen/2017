-- 04_MemoryOptimized_Sales_SalesOrderHeaderMO_withCustomer_Query
set	nocount	on
;

-- Baseline
declare	@letter					nchar(1)
;
set	@letter = N'P'
;
print	''
;
print	'Disk-based table w/ subquery'
;
print	'----------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeader
		inner join	(
				select	Person.BusinessEntityID
					,Person.PersonType
					,Person.NameStyle
					,Person.Title
					,Person.FirstName
					,Person.MiddleName
					,Person.LastName
					,Person.Suffix
					,Person.EmailPromotion
					,Person.AdditionalContactInfo
					,Person.Demographics
					,Person.rowguid
					,Person.ModifiedDate
					,Customer.CustomerID
					from	Person.Person
						inner join	Sales.Customer
								on	Customer.PersonID = Person.BusinessEntityID
					where	(Person.LastName like @letter + N'%')
				) Customer
				on	Customer.CustomerID = SalesOrderHeader.CustomerID
	--option	(
	--	force order
	--	)
;
set	statistics time	off
;
set	statistics io	off
;
print	''
;
print	'Memory-optimized table w/ subquery'
;
print	'----------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeaderMO
		inner join	(
				select	Person.BusinessEntityID
					,Person.PersonType
					,Person.NameStyle
					,Person.Title
					,Person.FirstName
					,Person.MiddleName
					,Person.LastName
					,Person.Suffix
					,Person.EmailPromotion
					,Person.AdditionalContactInfo
					,Person.Demographics
					,Person.rowguid
					,Person.ModifiedDate
					,Customer.CustomerID
					from	Person.Person
						inner join	Sales.Customer
								on	Customer.PersonID = Person.BusinessEntityID
					where	(Person.LastName like @letter + N'%')
				) Customer
				on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
go

-- Disk-based TVP
declare	@customer				Person.Customer
;
declare	@letter					nchar(1)
;
set	@letter = N'P'
;
insert	@customer
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID
		,Person.PersonType
		,Person.NameStyle
		,Person.Title
		,Person.FirstName
		,Person.MiddleName
		,Person.LastName
		,Person.Suffix
		,Person.EmailPromotion
		,Person.AdditionalContactInfo
		,Person.Demographics
		,Person.rowguid
		,Person.ModifiedDate
		,Customer.CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
		where	(Person.LastName like @letter + N'%')
;
print	''
;
print	'Disk-based table w/ disk-based TVP'
;
print	'----------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeader
		inner join	@customer Customer
				on	Customer.CustomerID = SalesOrderHeader.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
print	''
;
print	'Memory-optimized table w/ disk-based TVP'
;
print	'----------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeaderMO
		inner join	@customer Customer
				on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
go


-- Memory-optimized TVP, underprovisioned
declare	@customerUnder				Person.CustomerMO_Under
;
declare	@letter					nchar(1)
;
set	@letter = N'P'
;
insert	@customerUnder
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID as BusinessEntityID
		,Person.PersonType as PersonType
		,Person.NameStyle as NameStyle
		,Person.Title as Title
		,Person.FirstName as FirstName
		,Person.MiddleName as MiddleName
		,Person.LastName as LastName
		,Person.Suffix as Suffix
		,Person.EmailPromotion as EmailPromotion
		,cast(Person.AdditionalContactInfo as varbinary(4000)) as AdditionalContactInfo
		,cast(Person.Demographics as varbinary(2000)) as Demographics
		,Person.rowguid as rowguid
		,Person.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
		where	(Person.LastName like @letter + N'%')
;
print	''
;
print	'Disk-based table w/ underprovisioned memory-optimized TVP'
;
print	'---------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeader
		inner join	@customerUnder Customer
				on	Customer.CustomerID = SalesOrderHeader.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
print	''
;
print	'Memory-optimized table w/ underprovisioned memory-optimized TVP'
;
print	'---------------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeaderMO
		inner join	@customerUnder Customer
				on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
go


-- Memory-optimized TVP, overprovisioned
declare	@customerOver				Person.CustomerMO_Over
;
declare	@letter					nchar(1)
;
set	@letter = N'P'
;
insert	@customerOver
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID as BusinessEntityID
		,Person.PersonType as PersonType
		,Person.NameStyle as NameStyle
		,Person.Title as Title
		,Person.FirstName as FirstName
		,Person.MiddleName as MiddleName
		,Person.LastName as LastName
		,Person.Suffix as Suffix
		,Person.EmailPromotion as EmailPromotion
		,cast(Person.AdditionalContactInfo as varbinary(4000)) as AdditionalContactInfo
		,cast(Person.Demographics as varbinary(2000)) as Demographics
		,Person.rowguid as rowguid
		,Person.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
		where	(Person.LastName like @letter + N'%')
;
print	''
;
print	'Disk-based table w/ overprovisioned memory-optimized TVP'
;
print	'--------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeader
		inner join	@customerOver Customer
				on	Customer.CustomerID = SalesOrderHeader.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
print	''
;
print	'Memory-optimized table w/ overprovisioned memory-optimized TVP'
;
print	'--------------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
set	statistics io	on
;
set	statistics time	on
;
select	*
	from	Sales.SalesOrderHeaderMO
		inner join	@customerOver Customer
				on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
;
set	statistics time	off
;
set	statistics io	off
;
go


-- Memory-optimized Procedure and TVP
declare	@customerUnder				Person.CustomerMO_Under
;
declare	@customerOver				Person.CustomerMO_Over
;
declare	@letter					nchar(1)
;
set	@letter = N'P'
;
print	''
;
print	'Memory-optimized procedure w/ underprovisioned memory-optimized TVP'
;
print	'-------------------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
insert	@customerUnder
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID as BusinessEntityID
		,Person.PersonType as PersonType
		,Person.NameStyle as NameStyle
		,Person.Title as Title
		,Person.FirstName as FirstName
		,Person.MiddleName as MiddleName
		,Person.LastName as LastName
		,Person.Suffix as Suffix
		,Person.EmailPromotion as EmailPromotion
		,cast(Person.AdditionalContactInfo as varbinary(4000)) as AdditionalContactInfo
		,cast(Person.Demographics as varbinary(2000)) as Demographics
		,Person.rowguid as rowguid
		,Person.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
		where	(Person.LastName like @letter + N'%')
;
set	statistics io	on
;
set	statistics time	on
;
exec	Sales.SalesOrderHeader_Get_forCustomer_Under
		@Customer = @customerUnder
;
set	statistics time	off
;
set	statistics io	off
;
print	''
;
print	'Memory-optimized procedure w/ overprovisioned memory-optimized TVP'
;
print	'------------------------------------------------------------------'
;
dbcc freeproccache
;
dbcc dropcleanbuffers
;
insert	@customerOver
	(
	BusinessEntityID
	,PersonType
	,NameStyle
	,Title
	,FirstName
	,MiddleName
	,LastName
	,Suffix
	,EmailPromotion
	,AdditionalContactInfo
	,Demographics
	,rowguid
	,ModifiedDate
	,CustomerID
	)
	select	Person.BusinessEntityID as BusinessEntityID
		,Person.PersonType as PersonType
		,Person.NameStyle as NameStyle
		,Person.Title as Title
		,Person.FirstName as FirstName
		,Person.MiddleName as MiddleName
		,Person.LastName as LastName
		,Person.Suffix as Suffix
		,Person.EmailPromotion as EmailPromotion
		,cast(Person.AdditionalContactInfo as varbinary(4000)) as AdditionalContactInfo
		,cast(Person.Demographics as varbinary(2000)) as Demographics
		,Person.rowguid as rowguid
		,Person.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Person.Person
			inner join	Sales.Customer
					on	Customer.PersonID = Person.BusinessEntityID
		where	(Person.LastName like @letter + N'%')
;
set	statistics io	on
;
set	statistics time	on
;
exec	Sales.SalesOrderHeader_Get_forCustomer_Over
		@Customer = @customerOver
;
set	statistics time	off
;
set	statistics io	off
;
go
