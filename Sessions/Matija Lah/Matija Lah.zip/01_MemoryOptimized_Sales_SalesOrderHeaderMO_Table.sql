-- 01_MemoryOptimized_Sales_SalesOrderHeaderMO_Table
if	(object_id('Sales.SalesOrderHeaderMO') is not null)
	begin
		drop table	Sales.SalesOrderHeaderMO
	end
go

create table	Sales.SalesOrderHeaderMO
	(
	SalesOrderID			int									not null
	,RevisionNumber			tinyint									not null
	constraint	DF_SalesOrderHeaderMO_RevisionNumber
			default
			(
			(0)
			)
	,OrderDate			datetime								not null
	constraint	DF_SalesOrderHeaderMO_OrderDate
			default
			(
			getdate()
			)
	,DueDate			datetime								not null
	,ShipDate			datetime								null
	,Status				tinyint									not null
	constraint	DF_SalesOrderHeaderMO_Status
			default
			(
			(1)
			)
	,OnlineOrderFlag		bit									not null
	constraint	DF_SalesOrderHeaderMO_OnlineOrderFlag
			default
			(
			(1)
			)
	,PurchaseOrderNumber		nvarchar(25)								null
	,AccountNumber			nvarchar(15)								null
	,CustomerID			int									not null
	,SalesPersonID			int									null
	,TerritoryID			int									null
	,BillToAddressID		int									not null
	,ShipToAddressID		int									not null
	,ShipMethodID			int									not null
	,CreditCardID			int									null
	,CreditCardApprovalCode		varchar(15)								null
	,CurrencyRateID			int									null
	,SubTotal			money									not null
	constraint	DF_SalesOrderHeaderMO_SubTotal
			default
			(
			(0.00)
			)
	,TaxAmt				money									not null
	constraint	DF_SalesOrderHeaderMO_TaxAmt
			default
			(
			(0.00)
			)
	,Freight			money									not null
	constraint	DF_SalesOrderHeaderMO_Freight
			default
			(
			(0.00)
			)
	,Comment			nvarchar(128)								null
	,rowguid			uniqueidentifier							not null
	constraint	DF_SalesOrderHeaderMO_rowguid
			default
			(
			newid()
			)
	,ModifiedDate			datetime								not null
	constraint	DF_SalesOrderHeaderMO_ModifiedDate
			default
			(
			getdate()
			)
	,constraint	PK_SalesOrderHeaderMO_SalesOrderID
			primary key nonclustered hash
			(
			SalesOrderID
			)
			with	(
				bucket_count = 65536
				)
	,index		AK_SalesOrderHeaderMO_rowguid
			nonclustered hash
			(
			rowguid
			)
			with	(
				bucket_count = 65536
				)
	,index		UX_SalesOrderHeaderMO_CustomerID
			nonclustered hash
			(
			CustomerID
			)
			with	(
				bucket_count = 65536
				)
	)
	with	(
		memory_optimized = on
		,durability = schema_and_data
		)
go

insert	Sales.SalesOrderHeaderMO
	(
	SalesOrderID
	,RevisionNumber
	,OrderDate
	,DueDate
	,ShipDate
	,Status
	,OnlineOrderFlag
	,PurchaseOrderNumber
	,AccountNumber
	,CustomerID
	,SalesPersonID
	,TerritoryID
	,BillToAddressID
	,ShipToAddressID
	,ShipMethodID
	,CreditCardID
	,CreditCardApprovalCode
	,CurrencyRateID
	,SubTotal
	,TaxAmt
	,Freight
	,Comment
	,rowguid
	,ModifiedDate
	)
	select	SalesOrderHeader.SalesOrderID as SalesOrderID
		,SalesOrderHeader.RevisionNumber as RevisionNumber
		,SalesOrderHeader.OrderDate as OrderDate
		,SalesOrderHeader.DueDate as DueDate
		,SalesOrderHeader.ShipDate as ShipDate
		,SalesOrderHeader.Status as Status
		,SalesOrderHeader.OnlineOrderFlag as OnlineOrderFlag
		,SalesOrderHeader.PurchaseOrderNumber as PurchaseOrderNumber
		,SalesOrderHeader.AccountNumber as AccountNumber
		,SalesOrderHeader.CustomerID as CustomerID
		,SalesOrderHeader.SalesPersonID as SalesPersonID
		,SalesOrderHeader.TerritoryID as TerritoryID
		,SalesOrderHeader.BillToAddressID as BillToAddressID
		,SalesOrderHeader.ShipToAddressID as ShipToAddressID
		,SalesOrderHeader.ShipMethodID as ShipMethodID
		,SalesOrderHeader.CreditCardID as CreditCardID
		,SalesOrderHeader.CreditCardApprovalCode as CreditCardApprovalCode
		,SalesOrderHeader.CurrencyRateID as CurrencyRateID
		,SalesOrderHeader.SubTotal as SubTotal
		,SalesOrderHeader.TaxAmt as TaxAmt
		,SalesOrderHeader.Freight as Freight
		,SalesOrderHeader.Comment as Comment
		,SalesOrderHeader.rowguid as rowguid
		,SalesOrderHeader.ModifiedDate as ModifiedDate
		from	Sales.SalesOrderHeader
go
