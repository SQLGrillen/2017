-- 03_MemoryOptimized_Procedures_Script

-- Sales.SalesOrderHeader_Get_forCustomer_Under
if	(object_id('Sales.SalesOrderHeader_Get_forCustomer_Under') is not null)
	begin
		drop proc	Sales.SalesOrderHeader_Get_forCustomer_Under
	end
go

create proc	Sales.SalesOrderHeader_Get_forCustomer_Under
	(
	@Customer				Person.CustomerMO_Under					readonly
	)
	with	native_compilation
		,schemabinding
		,execute as owner
as
begin atomic
	with	(
		language = N'English'
		,transaction isolation level = snapshot
		)

	select	SalesOrderHeaderMO.SalesOrderID as SalesOrderID
		,SalesOrderHeaderMO.RevisionNumber as RevisionNumber
		,SalesOrderHeaderMO.OrderDate as OrderDate
		,SalesOrderHeaderMO.DueDate as DueDate
		,SalesOrderHeaderMO.ShipDate as ShipDate
		,SalesOrderHeaderMO.Status as Status
		,SalesOrderHeaderMO.OnlineOrderFlag as OnlineOrderFlag
		,SalesOrderHeaderMO.PurchaseOrderNumber as PurchaseOrderNumber
		,SalesOrderHeaderMO.AccountNumber as AccountNumber
		,SalesOrderHeaderMO.CustomerID as CustomerID
		,SalesOrderHeaderMO.SalesPersonID as SalesPersonID
		,SalesOrderHeaderMO.TerritoryID as TerritoryID
		,SalesOrderHeaderMO.BillToAddressID as BillToAddressID
		,SalesOrderHeaderMO.ShipToAddressID as ShipToAddressID
		,SalesOrderHeaderMO.ShipMethodID as ShipMethodID
		,SalesOrderHeaderMO.CreditCardID as CreditCardID
		,SalesOrderHeaderMO.CreditCardApprovalCode as CreditCardApprovalCode
		,SalesOrderHeaderMO.CurrencyRateID as CurrencyRateID
		,SalesOrderHeaderMO.SubTotal as SubTotal
		,SalesOrderHeaderMO.TaxAmt as TaxAmt
		,SalesOrderHeaderMO.Freight as Freight
		,SalesOrderHeaderMO.Comment as Comment
		,SalesOrderHeaderMO.rowguid as rowguid
		,SalesOrderHeaderMO.ModifiedDate as ModifiedDate
		,Customer.BusinessEntityID as BusinessEntityID
		,Customer.PersonType as PersonType
		,Customer.NameStyle as NameStyle
		,Customer.Title as Title
		,Customer.FirstName as FirstName
		,Customer.MiddleName as MiddleName
		,Customer.LastName as LastName
		,Customer.Suffix as Suffix
		,Customer.EmailPromotion as EmailPromotion
		,Customer.AdditionalContactInfo as AdditionalContactInfo
		,Customer.Demographics as Demographics
		,Customer.rowguid as rowguid
		,Customer.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Sales.SalesOrderHeaderMO
			inner join	@customer Customer
					on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
end
go


-- Sales.SalesOrderHeader_Get_forCustomer_Over
if	(object_id('Sales.SalesOrderHeader_Get_forCustomer_Over') is not null)
	begin
		drop proc	Sales.SalesOrderHeader_Get_forCustomer_Over
	end
go

create proc	Sales.SalesOrderHeader_Get_forCustomer_Over
	(
	@Customer				Person.CustomerMO_Over					readonly
	)
	with	native_compilation
		,schemabinding
		,execute as owner
as
begin atomic
	with	(
		language = N'English'
		,transaction isolation level = snapshot
		)

	select	SalesOrderHeaderMO.SalesOrderID as SalesOrderID
		,SalesOrderHeaderMO.RevisionNumber as RevisionNumber
		,SalesOrderHeaderMO.OrderDate as OrderDate
		,SalesOrderHeaderMO.DueDate as DueDate
		,SalesOrderHeaderMO.ShipDate as ShipDate
		,SalesOrderHeaderMO.Status as Status
		,SalesOrderHeaderMO.OnlineOrderFlag as OnlineOrderFlag
		,SalesOrderHeaderMO.PurchaseOrderNumber as PurchaseOrderNumber
		,SalesOrderHeaderMO.AccountNumber as AccountNumber
		,SalesOrderHeaderMO.CustomerID as CustomerID
		,SalesOrderHeaderMO.SalesPersonID as SalesPersonID
		,SalesOrderHeaderMO.TerritoryID as TerritoryID
		,SalesOrderHeaderMO.BillToAddressID as BillToAddressID
		,SalesOrderHeaderMO.ShipToAddressID as ShipToAddressID
		,SalesOrderHeaderMO.ShipMethodID as ShipMethodID
		,SalesOrderHeaderMO.CreditCardID as CreditCardID
		,SalesOrderHeaderMO.CreditCardApprovalCode as CreditCardApprovalCode
		,SalesOrderHeaderMO.CurrencyRateID as CurrencyRateID
		,SalesOrderHeaderMO.SubTotal as SubTotal
		,SalesOrderHeaderMO.TaxAmt as TaxAmt
		,SalesOrderHeaderMO.Freight as Freight
		,SalesOrderHeaderMO.Comment as Comment
		,SalesOrderHeaderMO.rowguid as rowguid
		,SalesOrderHeaderMO.ModifiedDate as ModifiedDate
		,Customer.BusinessEntityID as BusinessEntityID
		,Customer.PersonType as PersonType
		,Customer.NameStyle as NameStyle
		,Customer.Title as Title
		,Customer.FirstName as FirstName
		,Customer.MiddleName as MiddleName
		,Customer.LastName as LastName
		,Customer.Suffix as Suffix
		,Customer.EmailPromotion as EmailPromotion
		,Customer.AdditionalContactInfo as AdditionalContactInfo
		,Customer.Demographics as Demographics
		,Customer.rowguid as rowguid
		,Customer.ModifiedDate as ModifiedDate
		,Customer.CustomerID as CustomerID
		from	Sales.SalesOrderHeaderMO
			inner join	@customer Customer
					on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
end
go
