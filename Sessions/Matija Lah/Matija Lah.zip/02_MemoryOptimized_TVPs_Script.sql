-- 02_MemoryOptimized_TVPs_Script

-- Person.Customer
if	(type_id('Person.Customer') is not null)
	begin
		drop type	Person.Customer
	end
go

create type	Person.Customer
as	table
	(
	BusinessEntityID		int								not null
	,PersonType			nchar(2)							not null
	,NameStyle			bit								not null
	,Title				nvarchar(8)							null
	,FirstName			nvarchar(50)							not null
	,MiddleName			nvarchar(50)							null
	,LastName			nvarchar(50)							not null
	,Suffix				nvarchar(10)							null
	,EmailPromotion			int								not null
	,AdditionalContactInfo		xml(Person.AdditionalContactInfoSchemaCollection)		null
	,Demographics			xml(Person.IndividualSurveySchemaCollection)			null
	,rowguid			uniqueidentifier		rowguidcol			not null
	,ModifiedDate			datetime							not null
	,CustomerID			int								not null
	,primary key clustered
		(
		CustomerId
		)
	)
go

-- Person.CustomerMO_Under
if	(type_id('Person.CustomerMO_Under') is not null)
	begin
		drop type	Person.CustomerMO_Under
	end
go

create type	Person.CustomerMO_Under
as	table
	(
	BusinessEntityID		int								not null
	,PersonType			nchar(2)							not null
	,NameStyle			bit								not null
	,Title				nvarchar(8)							null
	,FirstName			nvarchar(50)							not null
	,MiddleName			nvarchar(50)							null
	,LastName			nvarchar(50)							not null
	,Suffix				nvarchar(10)							null
	,EmailPromotion			int								not null
	,AdditionalContactInfo		varbinary(4000)							null
	,Demographics			varbinary(2000)							null
	,rowguid			uniqueidentifier						not null
	,ModifiedDate			datetime							not null
	,CustomerID			int								not null
	,primary key nonclustered hash
		(
		CustomerID
		)
		with	(
			bucket_count = 2
			)
	)
	with	(
		memory_optimized = on
		)
go

-- Person.CustomerMO_Over
if	(type_id('Person.CustomerMO_Over') is not null)
	begin
		drop type	Person.CustomerMO_Over
	end
go

create type	Person.CustomerMO_Over
as	table
	(
	BusinessEntityID		int								not null
	,PersonType			nchar(2)							not null
	,NameStyle			bit								not null
	,Title				nvarchar(8)							null
	,FirstName			nvarchar(50)							not null
	,MiddleName			nvarchar(50)							null
	,LastName			nvarchar(50)							not null
	,Suffix				nvarchar(10)							null
	,EmailPromotion			int								not null
	,AdditionalContactInfo		varbinary(4000)							null
	,Demographics			varbinary(2000)							null
	,rowguid			uniqueidentifier						not null
	,ModifiedDate			datetime							not null
	,CustomerID			int								not null
	,primary key nonclustered hash
		(
		CustomerID
		)
		with	(
			bucket_count = 8192
			)
	)
	with	(
		memory_optimized = on
		)
go
