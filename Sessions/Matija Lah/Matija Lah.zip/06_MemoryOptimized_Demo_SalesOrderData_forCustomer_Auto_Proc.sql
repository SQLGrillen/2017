-- 06_MemoryOptimized_Demo_SalesOrderData_forCustomer_Auto_Proc
if	(object_id('Demo.SalesOrderData_forCustomer_Auto') is not null)
	begin
		drop proc	Demo.SalesOrderData_forCustomer_Auto
	end
go

create proc	Demo.SalesOrderData_forCustomer_Auto
	(
	@Option					sysname
	)
as
begin
	declare	@letter					nchar(1)
	declare	@customer				Person.Customer
	declare	@customerUnder				Person.CustomerMO_Under
	declare	@customerOver				Person.CustomerMO_Over

	set	nocount	on

	set	@letter
			= (
			select	top(1)
				Person.FirstLetter
				from	(
					select	distinct
						left(LastName, 1) as FirstLetter
						from	Person.Person
					) Person
				order by	newid()
			)

	if	(@Option = 'DBT_Sub')
		begin
			select	*
				from	Sales.SalesOrderHeader
					inner join	(
							select	Person.BusinessEntityID
								,Person.PersonType
								,Person.NameStyle
								,Person.Title
								,Person.FirstName
								,Person.MiddleName
								,Person.LastName
								,Person.Suffix
								,Person.EmailPromotion
								,Person.AdditionalContactInfo
								,Person.Demographics
								,Person.rowguid
								,Person.ModifiedDate
								,Customer.CustomerID
								from	Person.Person
									inner join	Sales.Customer
											on	Customer.PersonID = Person.BusinessEntityID
								where	(Person.LastName like @letter + N'%')
							) Customer
							on	Customer.CustomerID = SalesOrderHeader.CustomerID
		end

	if	(@Option = 'MOT_Sub')
		begin
			select	*
				from	Sales.SalesOrderHeaderMO
					inner join	(
							select	Person.BusinessEntityID
								,Person.PersonType
								,Person.NameStyle
								,Person.Title
								,Person.FirstName
								,Person.MiddleName
								,Person.LastName
								,Person.Suffix
								,Person.EmailPromotion
								,Person.AdditionalContactInfo
								,Person.Demographics
								,Person.rowguid
								,Person.ModifiedDate
								,Customer.CustomerID
								from	Person.Person
									inner join	Sales.Customer
											on	Customer.PersonID = Person.BusinessEntityID
								where	(Person.LastName like @letter + N'%')
							) Customer
							on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
		end

	if	(@Option = 'DBT_DBP')
		begin
			insert	@customer
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeader
					inner join	@customer Customer
							on	Customer.CustomerID = SalesOrderHeader.CustomerID
		end

	if	(@Option = 'MOT_DBP')
		begin
			insert	@customer
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeaderMO
					inner join	@customer Customer
							on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
		end

	if	(@Option = 'DBT_MOP_U')
		begin
			insert	@customerUnder
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeader
					inner join	@customerUnder Customer
							on	Customer.CustomerID = SalesOrderHeader.CustomerID
		end

	if	(@Option = 'MOT_MOP_U')
		begin
			insert	@customerUnder
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeaderMO
					inner join	@customerUnder Customer
							on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
		end

	if	(@Option = 'DBT_MOP_O')
		begin
			insert	@customerOver
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeader
					inner join	@customerOver Customer
							on	Customer.CustomerID = SalesOrderHeader.CustomerID
		end

	if	(@Option = 'MOT_MOP_O')
		begin
			insert	@customerOver
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			select	*
				from	Sales.SalesOrderHeaderMO
					inner join	@customerOver Customer
							on	Customer.CustomerID = SalesOrderHeaderMO.CustomerID
		end

	if	(@Option = 'MOM_MOP_U')
		begin
			insert	@customerUnder
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			exec	Sales.SalesOrderHeader_Get_forCustomer_Under
					@Customer = @customerUnder
		end

	if	(@Option = 'MOM_MOP_O')
		begin
			insert	@customerOver
				(
				BusinessEntityID
				,PersonType
				,NameStyle
				,Title
				,FirstName
				,MiddleName
				,LastName
				,Suffix
				,EmailPromotion
				,AdditionalContactInfo
				,Demographics
				,rowguid
				,ModifiedDate
				,CustomerID
				)
				select	CustomerMO.BusinessEntityID
					,CustomerMO.PersonType
					,CustomerMO.NameStyle
					,CustomerMO.Title
					,CustomerMO.FirstName
					,CustomerMO.MiddleName
					,CustomerMO.LastName
					,CustomerMO.Suffix
					,CustomerMO.EmailPromotion
					,CustomerMO.AdditionalContactInfo
					,CustomerMO.Demographics
					,CustomerMO.rowguid
					,CustomerMO.ModifiedDate
					,CustomerMO.CustomerID
					from	Person.CustomerMO
					where	(CustomerMO.LastName like @letter + N'%')

			exec	Sales.SalesOrderHeader_Get_forCustomer_Over
					@Customer = @customerOver
		end

	return	0
end
go
