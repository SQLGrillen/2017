--------------------------------------------------------------------------------
SQL Server 2014: Extreme Transaction Processing, Table-valued Parameters and
Table Variables

(c) 2015 Matija Lah
--------------------------------------------------------------------------------
Session Samples
--------------------------------------------------------------------------------
To perform the initial test:

1. Deploy the AdventureWorks2014 sample database to your SQL Server 2014
instance. You can download the sample database from the Codeplex web site,
at: https://msftdbprodsamples.codeplex.com/releases/view/125550.

2. Add the SQL Server 2014 RTM In-Memory OLTP Sample to the AdventureWorks2014
database. You can download the sample from the Codeplex web site, at:
https://msftdbprodsamples.codeplex.com/releases/view/114491.

3. Carefully inspect, and then execute the following Transact-SQL scripts, in
the order indicated, to create the initial sample objects:

01_MemoryOptimized_Sales_SalesOrderHeaderMO_Table.sql
02_MemoryOptimized_TVPs_Script.sql
03_MemoryOptimized_Procedures_Script.sql

4. Carefully inspect, and then execute, the following script, and observe the
result sets, and the available statistical data about the executions:

04_MemoryOptimized_Sales_SalesOrderHeaderMO_withCustomer_Query.sql
--------------------------------------------------------------------------------
To run the automated stress test:

1. Carefully inspect, and then execute the following Transact-SQL scripts, in
the order indicated, to create the additional sample objects used for the stress
test:

05_MemoryOptimized_Person_CustomerMO_Table.sql
06_MemoryOptimized_Demo_SalesOrderData_forCustomer_Auto_Proc.sql

2. Make sure the ostress command-line utility is available at your test server.
You can download the utility from the Microsoft web site, at:
http://www.microsoft.com/en-us/download/details.aspx?id=4511 (64-bit)
http://www.microsoft.com/en-us/download/details.aspx?id=8161 (32-bit)

3. Copy the .BAT files to the folder where the RML ostress utility is located;
by default, the utility will be installed in the following folder:
%ProgramFiles%\Microsoft Corporation\RMLUtils (64-bit)
%ProgramFiles(x68)%\Microsoft Corporation\RMLUtils (32-bit)

4. Based on your particular environment, make the necessary adjustments to the
following ostress command-line arguments:
-S - the name of the SQL Server 2014 instance to be used for testing.
-E - replace with the -U and -P arguments in order to use SQL Server
authentication when connecting to the SQL Server instance;
-d - the name of the database used in the test;
-o - the name of the folder used for any stress test output files;
-n - the number of concurrent connections started by the utility;
-r - the number of times the query is executed by each connection.

5. Perform the test either by running the RunAll.bat command file, or by
running individual tests using the following command files:

01_DBT_Sub.bat - disk-based table with sub-query;
02_MOT_Sub.bat - memory-optimized table with sub-query;
03_DBT_DBP.bat - disk-based table with disk-based parameter;
04_MOT_DBP.bat - memory-optimized table with disk-based parameter;
05_DBT_MOP_U.bat - disk-based table with under-provisioned memory optimized
parameter;
06_MOT_MOP_U.bat - memory-optimized table with under-provisioned memory optimized
parameter;
07_DBT_MOP_O.bat - disk-based table with over-provisioned memory optimized
parameter;
08_MOT_MOP_O.bat - memory-optimized table with over-provisioned memory optimized
parameter;
09_MOM_MOP_U.bat - native procedure with under-provisioned memory optimized
parameter;
10_MOM_MOP_O.bat - native procedure with over-provisioned memory optimized
parameter.

6. Use your favourite monitoring tool to observe the behaviour of the SQL Server
instance during the test; inspect the log files created by the ostress utility
after each execution.
--------------------------------------------------------------------------------
