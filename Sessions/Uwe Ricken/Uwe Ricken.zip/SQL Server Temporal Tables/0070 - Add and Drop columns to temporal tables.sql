/*============================================================================
	File:		0070 - Add and Drop columns to temporal tables.sql

	Summary:	This script demonstrates the handling of temporal tables
				when new columns will be added or existing columns will
				be dropped from a table.

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- prepare the workbench!
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
	@fill_data = 1;
	GO

-- now we change a few records by adding an email address to it
DECLARE	@Customer_Id INT = RAND() * 85000 + 1;
DECLARE	@I INT = 1;
WHILE @I <= 1000
BEGIN
	RAISERROR ('Updating Id = %i', 0, 1, @Customer_Id) WITH NOWAIT;
	UPDATE	demo.Customers
	SET		EMail = 'This_is_a_test@online.de'
	WHERE	Id = @Customer_Id;

	SET @Customer_Id = RAND() * 85000 + 1;
	SET @I += 1;
END
GO

-- what will happen to the history table relationship when new columns will be added?
-- DEMO 1:	Add a new NULLable column
ALTER TABLE demo.Customers
ADD	[Fax] VARCHAR(20) NULL;
GO

-- Update all customers
UPDATE	C
SET		C.[Fax] = Fax.[Property_Value]
FROM	demo.Customers AS C
		CROSS APPLY
		(
			SELECT	Property_Value
			FROM	dbo.CustomerProperties AS CP
			WHERE	CP.Customer_Id = C.Id
					AND CP.Property_Id = 2
		) AS Fax;
GO

-- DEMO 2:	Add a new NOT NULLable column to the temporary table
-- Now we add a new NOT NULLable column to the table...
ALTER TABLE demo.Customers
ADD	[Mobile] VARCHAR(20) NOT NULL
CONSTRAINT df_Customers_EMail DEFAULT ('not given');
GO

SELECT * FROM history.Customers;
GO

-- will the default value be stored PHYSICALLY in the history table?
SELECT� c.name������������������� AS column_name,
������� pc.modified_count,
������� pc.max_inrow_length,
������� pc.has_default,
������� pc.default_value
FROM��� sys.system_internals_partitions p INNER JOIN
		sys.system_internals_partition_columns pc
������� ON (p.partition_id = pc.partition_id) INNER JOIN
		sys.columns c
������� ON (
������������ p.object_id = c.object_id AND
������������ pc.partition_column_id = c.column_id
���������� )
WHERE��� p.object_id = object_id('history.Customers')
ORDER BY
������� c.column_id ASC;
GO

-- now we update all mobile numbers in the table!
UPDATE	C
SET		[Mobile] = Mobile.[Property_Value]
FROM	demo.Customers AS C
		CROSS APPLY
		(
			SELECT	Property_Value
			FROM	dbo.CustomerProperties AS CP
			WHERE	CP.Customer_Id = C.Id
					AND CP.Property_Id = 1
		) AS Mobile;
GO

-- DEMO 3:	Add a new NOT NULLable column with NO default...
ALTER TABLE demo.Customers
ADD	[Pager] VARCHAR(20) NOT NULL;
GO


/*
	HOW ABOUT DROPPING COLUMNS???
	DO NOT DO THIS IN PRODUCTION!!!
	DO NOT DO THIS IN PRODUCTION!!!
	DO NOT DO THIS IN PRODUCTION!!!	
*/
ALTER TABLE demo.Customers DROP CONSTRAINT df_Customers_EMail;
ALTER TABLE demo.Customers DROP COLUMN [Mobile];
GO

SELECT * FROM history.Customers;
GO

-- Clean the kitchen
EXEC dbo.sp_prepare_workbench
    @remove_all = 1;
	GO
