/*============================================================================
	File:		0040 - creation of temporal tables.sql

	Summary:	This script demonstrates the different ways to create/implement
				the system versioned temporal table concept

				- use the default naming convention of Microsoft SQL Server
				- use a dedicated schema and named (new) table
				- use a dedicated schema and an existing history table

	Date:		October 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
GO

USE CustomerOrders;
GO

-- Example 1: Temporal Tables mit DEFAULT table by SQL Server!
-- The table dbo.Customers will be implemented as a system versioned table

-- MAKE SURE A PRIMARY KEY EXISTS!
IF NOT EXISTS
(
	SELECT	KC.*
	FROM	sys.key_constraints AS KC
	WHERE	KC.parent_object_id = OBJECT_ID(N'dbo.Customers', N'U')
			AND type = N'PK'
)
ALTER TABLE dbo.Customers ADD CONSTRAINT pk_Customers_Id PRIMARY KEY CLUSTERED (Id);
GO

-- Now the period columns have to be added
IF NOT EXISTS
(
	SELECT * FROM sys.columns
	WHERE	OBJECT_ID = OBJECT_ID(N'dbo.Customers', N'U')
			AND name IN (N'StartTime', N'EndTime')
)
ALTER TABLE dbo.Customers
ADD
	[StartTime] DATETIME2(0) GENERATED ALWAYS AS ROW START CONSTRAINT df_Customers_StartTime DEFAULT ('2016-10-01T00:00:00'),
	[EndTime] DATETIME2(0) GENERATED ALWAYS AS ROW END CONSTRAINT df_Customers_EndTime DEFAULT ('9999-12-31T23:59:59'),
	PERIOD FOR SYSTEM_TIME(StartTime, EndTime);
GO

ALTER TABLE dbo.Customers
SET (SYSTEM_VERSIONING = ON);
GO

;WITH root
AS
(
	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T
	WHERE	OBJECT_ID = OBJECT_ID(N'dbo.Customers', N'U')

	UNION ALL

	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T INNER JOIN root AS R
			ON (T.object_id = R.history_table_id)
)
SELECT * FROM root;
GO

-- what indexes have been created in the history table?
SELECT	I.*
FROM	sys.indexes AS I INNER JOIN sys.tables AS T
		ON (I.object_id = T.history_table_id)
WHERE	T.object_id = OBJECT_ID(N'dbo.Customers', N'U');
GO

-- clean the kitchen
ALTER TABLE dbo.Customers SET (SYSTEM_VERSIONING = OFF);
DROP TABLE dbo.MSSQL_TemporalHistoryFor_309576141;
GO

/*
	Example 2:	Using a named history table which does not exist
*/
-- Create a dedicated schema for the history table(s)
IF OBJECT_ID(N'history.Customers', N'U') IS NOT NULL
	DROP TABLE history.Customers;
	GO

IF SCHEMA_ID(N'history') IS NULL
	EXEC sp_executesql N'CREATE SCHEMA [history] AUTHORZIATION dbo;';
	GO

ALTER TABLE dbo.Customers SET
(
	SYSTEM_VERSIONING = ON (HISTORY_TABLE = history.Customers)
);
GO

;WITH root
AS
(
	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T
	WHERE	OBJECT_ID = OBJECT_ID(N'dbo.Customers', N'U')

	UNION ALL

	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T INNER JOIN root AS R
			ON (T.object_id = R.history_table_id)
)
SELECT * FROM root;
GO

-- what indexes have been created in the history table?
SELECT	I.*
FROM	sys.indexes AS I INNER JOIN sys.tables AS T
		ON (I.object_id = T.history_table_id)
WHERE	T.object_id = OBJECT_ID(N'dbo.Customers', N'U');
GO

-- Example 3:	Usage of given history table name
ALTER TABLE dbo.Customers SET (SYSTEM_VERSIONING = OFF);
DROP TABLE history.Customers;
GO

CREATE TABLE history.Customers
(
	Id			INT				NOT NULL,
	Name		VARCHAR(200)	NOT NULL,
	InsertUser	SYSNAME			NOT NULL,
	InsertDate	DATETIME		NOT NULL,
	StartTime	DATETIME2(0)	NOT NULL,
	EndTime		DATETIME2(0)	NOT NULL
);
GO

ALTER TABLE dbo.Customers SET
(
	SYSTEM_VERSIONING = ON (HISTORY_TABLE = history.Customers)
);
GO

;WITH root
AS
(
	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T
	WHERE	OBJECT_ID = OBJECT_ID(N'dbo.Customers', N'U')

	UNION ALL

	SELECT	T.object_id,
			SCHEMA_NAME(T.schema_id)	AS	[SCHEMA],
			T.name,
			T.temporal_type,
			T.temporal_type_desc,
			T.history_table_id
	FROM	sys.tables AS T INNER JOIN root AS R
			ON (T.object_id = R.history_table_id)
)
SELECT * FROM root;
GO

-- DRAWBACK:	NO INDEXES!!!!
SELECT	I.*
FROM	sys.indexes AS I INNER JOIN sys.tables AS T
		ON (I.object_id = T.history_table_id)
WHERE	T.object_id = OBJECT_ID(N'dbo.Customers', N'U');
GO

-- Example 3:	Usage of HIDDEN period columns
SELECT * FROM dbo.Customers;
GO

ALTER TABLE dbo.Customers ALTER COLUMN StartTime ADD HIDDEN;
ALTER TABLE dbo.Customers ALTER COLUMN EndTime ADD HIDDEN;
GO

SELECT * FROM dbo.Customers;
GO

-- clean the kitchen
ALTER TABLE dbo.Customers SET (SYSTEM_VERSIONING = OFF);
DROP TABLE history.Customers;

ALTER TABLE dbo.Customers DROP CONSTRAINT df_Customers_StartTime;
ALTER TABLE dbo.Customers DROP CONSTRAINT df_Customers_EndTime;
GO

ALTER TABLE dbo.Customers DROP PERIOD FOR SYSTEM_TIME;
ALTER TABLE dbo.Customers DROP COLUMN StartTime;
ALTER TABLE dbo.Customers DROP COLUMN EndTime;
GO

-- Drop the PK-Constraint
ALTER TABLE dbo.Customers DROP CONSTRAINT pk_Customers_Id;
GO
