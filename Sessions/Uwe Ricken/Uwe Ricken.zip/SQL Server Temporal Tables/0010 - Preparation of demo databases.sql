/*============================================================================
	File:		0010 - Preparation of demo databases.sql

	Summary:	This script restores the database CustomerOrders from
				the backup medium for distribution of data.
				
				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Temporal Tables - deep insides"

	Date:		October 2016

	SQL Server Version: 2012 / 2014 / 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE master;
GO

-- Restore of the database CustomerOrders from BACKUP media
IF DB_ID('CustomerOrders') IS NOT NULL
BEGIN
	ALTER DATABASE CustomerOrders SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
	DROP DATABASE CustomerOrders;
END
GO

DECLARE @SourcePath NVARCHAR(200) = N'S:\Backup\CustomerOrders.bak';
DECLARE @FilePath NVARCHAR(200) = N'F:\MSSQL13.SQL_2016\MSSQL\DATA\CustomerOrders.mdf';
DECLARE @LogPath NVARCHAR(200) = N'L:\MSSQL13.SQL_2016\MSSQL\DATA\CustomerOrders.ldf'

RAISERROR ('Database %s will be restored for data distribution', 0, 1, 'CustomerOrders') WITH NOWAIT;
RESTORE DATABASE CustomerOrders
FROM DISK = @SourcePath
WITH
	MOVE N'CustomerOrders_Data' TO @FilePath,
	MOVE N'CustomerOrders_Log' TO @LogPath,
	STATS = 20,
	REPLACE;
GO

ALTER AUTHORIZATION ON DATABASE::[CustomerOrders] TO sa;
ALTER DATABASE [CustomerOrders] SET RECOVERY SIMPLE;
GO

USE CustomerOrders;
GO

IF OBJECT_ID(N'dbo.sp_prepare_workbench', N'P') IS NOT NULL
	DROP PROCEDURE dbo.sp_prepare_workbench;
	GO

RAISERROR (N'wrapper procedure dbo.sp_prepare_workbench will be created...', 0, 1) WITH NOWAIT;
GO

CREATE PROCEDURE dbo.sp_prepare_workbench
	@create_tables	BIT	=	0,
	@fill_data		BIT	=	0,
	@remove_all		BIT	=	0
AS
	SET NOCOUNT ON;

	IF @create_tables = 1 AND @remove_all = 1
	BEGIN
		RAISERROR (N'contradiction for variables @create_tables and @remove_all', 11, 1) WITH NOWAIT;
		RETURN;
	END

	-- if @create_tables s activated the demo.customers and history.customers
	-- will be created
	IF @create_tables = 1
	BEGIN
		-- Create a dedicated schema for the demo tables!
		IF SCHEMA_ID(N'demo') IS NULL
			EXEC sp_executesql N'CREATE SCHEMA [demo] AUTHORIZATION dbo;';

		-- Create a dedicated schema for the history data
		IF SCHEMA_ID(N'history') IS NULL
			EXEC sp_executesql N'CREATE SCHEMA [history] AUTHORIZATION dbo;';


		-- Clear the workbench for the demos!
		IF EXISTS
		(
			SELECT	*
			FROM	sys.tables AS T
			WHERE	T.object_id = OBJECT_ID(N'demo.Customers', N'U')
					AND T.temporal_type = 2
		)
			ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = OFF);

		IF OBJECT_ID(N'demo.Customers', N'U') IS NOT NULL
			DROP TABLE demo.Customers;

		IF OBJECT_ID(N'history.Customers', N'U') IS NOT NULL			
			DROP TABLE history.Customers;

		-- Create the demo table...
		CREATE TABLE demo.Customers
		(
			Id			INT				NOT NULL	IDENTITY (1, 1),
			Name		VARCHAR(100)	NOT NULL,
			Street		VARCHAR(100)	NOT NULL,
			ZIP			CHAR(5)			NOT NULL,
			City		VARCHAR(100)	NOT NULL,
			Phone		VARCHAR(20)		NULL,
			EMail		VARCHAR(255)	NULL,
			ValidFrom	DATETIME2(0)	GENERATED ALWAYS AS ROW START	NOT NULL	DEFAULT ('1900-01-01T00:00:00'),
			ValidTo		DATETIME2(0)	GENERATED ALWAYS AS ROW END		NOT NULL	DEFAULT ('9999-12-31T23:59:59'),

			CONSTRAINT pk_Customers_ID PRIMARY KEY CLUSTERED (Id),
			PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo)
		)
		WITH
		(
			SYSTEM_VERSIONING = ON
			(HISTORY_TABLE = History.Customers)
		);

		RAISERROR (N'demo tables have been created...', 1, 0) WITH NOWAIT;
	END

	IF @fill_data = 1
	BEGIN
		DECLARE	@num_rows	INT;

		INSERT INTO demo.Customers WITH (TABLOCK)
		(Name, Street, ZIP, City, Phone, EMail)
		SELECT	C.Name,
				A.Street,
				A.ZIP,
				A.City,
				Phone.Property_Value	AS	Phone,
				NULL					AS	EMail
		FROM	dbo.Customers AS C
				INNER JOIN dbo.CustomerAddresses AS CA ON (C.Id = CA.Customer_Id)
				INNER JOIN dbo.Addresses AS A ON (CA.Address_Id = A.Id)
				OUTER APPLY
				(
					SELECT	Property_Value FROM dbo.CustomerProperties AS CP
					WHERE	Customer_Id = C.Id
							AND CP.Property_Id = 1
				) AS Phone
		WHERE	CA.IsDefault = 1
		ORDER BY
				C.Id ASC;

		SET	@num_rows = @@ROWCOUNT;
		RAISERROR (N'demo tables have been filled with %i records...', 1, 0, @num_rows) WITH NOWAIT;
	END
	SET NOCOUNT OFF;

	IF @remove_all = 1
	BEGIN
		-- Clear the workbench for the demos!
		IF EXISTS
		(
			SELECT	*
			FROM	sys.tables AS T
			WHERE	T.object_id = OBJECT_ID(N'demo.Customers', N'U')
					AND T.temporal_type = 2
		)
			ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = OFF);

		IF OBJECT_ID(N'demo.Customers', N'U') IS NOT NULL
			DROP TABLE demo.Customers;

		IF OBJECT_ID(N'history.Customers', N'U') IS NOT NULL			
			DROP TABLE history.Customers;

		-- drop the schemes for the demo tables!
		IF SCHEMA_ID(N'demo') IS NULL
			EXEC sp_executesql N'DROP SCHEMA [demo];';

		-- Create a dedicated schema for the history data
		IF SCHEMA_ID(N'history') IS NULL
			EXEC sp_executesql N'DROP SCHEMA [history];';

		RAISERROR ('Objects and schemas have been removed...', 0, 1) WITH NOWAIT;
	END
GO