/*============================================================================
	File:		0090 - renaming objects in temporal relationships

	Summary:	This script demonstrates all different situations when
				an object in a temporal relationship will be renamed:
				- System Versioned Temporal Table
				- History Table
				- Column Name

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- Create a dedicated schema for the demo tables!
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
	@fill_data = 1;
	GO

-- what is the relation between both tables
SELECT	object_id,
		QUOTENAME(SCHEMA_NAME(schema_id)) + N'.' + QUOTENAME(name)	AS	TableName,
		temporal_type,
		temporal_type_desc,
		history_table_id
FROM	sys.tables
WHERE	object_id = OBJECT_ID(N'demo.Customers', N'U')

UNION ALL

SELECT	object_id,
		QUOTENAME(SCHEMA_NAME(schema_id)) + N'.' + QUOTENAME(name)	AS	TableName,
		temporal_type,
		temporal_type_desc,
		history_table_id
FROM	sys.tables
WHERE	object_id = OBJECT_ID(N'history.Customers', N'U');
GO

-- Now we try to rename the table!
EXEC sp_rename
	@objname = N'demo.Customers',
	@newname = N'NewCustomers',
	@objtype = N'OBJECT';
GO

-- what about renaming the history table?
EXEC sp_rename
	@objname = N'history.Customers',
	@newname = N'NewCustomers',
	@objtype = N'OBJECT';
GO

-- Now we try to rename a column of the "System Versioned Temporal Table"
EXEC sp_rename
	@objname = N'demo.NewCustomers.Name',
	@newname = N'CustomerName',
	@objtype = N'COLUMN';
GO

-- will it work with renaming a column in the history table?
EXEC sp_rename
	@objname = N'history.NewCustomers.Street',
	@newname = N'CustomerStreet',
	@objtype = N'COLUMN';
GO

-- Deactivate System Versioning and change the attributes
BEGIN TRANSACTION;
GO
	ALTER TABLE demo.NewCustomers SET (SYSTEM_VERSIONING = OFF);
	GO

	-- Now we can change the attributes in the history table
	EXEC sp_rename
		@objname = N'history.NewCustomers.Street',
		@newname = N'CustomerStreet',
		@objtype = N'COLUMN';
	GO

	-- but need to change it in the System Versioned Table, too!
	EXEC sp_rename
		@objname = N'demo.NewCustomers.Street',
		@newname = N'CustomerStreet',
		@objtype = N'COLUMN';
	GO

	-- can we now activate System Versioning?
	ALTER TABLE demo.NewCustomers
	SET
		(
			SYSTEM_VERSIONING = ON
			(HISTORY_TABLE = History.NewCustomers)
		);
	GO
COMMIT TRANSACTION;
GO

-- Clean the kitchen!
ALTER TABLE demo.NewCustomers SET (SYSTEM_VERSIONING = OFF);
DROP TABLE history.NewCustomers;
DROP TABLE demo.NewCustomers;
GO