/*============================================================================
	File:		0140 - temporal tables and row level security.sql

	Summary:	This script is part of the "temporal tables" session and
				demonstrates the behavior of row level security in conjunction
				with System Versioned Temporal Tables

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

EXEC dbo.sp_prepare_workbench
	@create_tables = 1, -- bit
	@fill_data = 1;
GO

-- Now we create the environment for the demos
-- 3 database roles will be created for the alphabetic preselection of customers
CREATE ROLE [A-H] AUTHORIZATION [dbo];
CREATE ROLE [I-P] AUTHORIZATION [dbo];
CREATE ROLE [Q-Z] AUTHORIZATION [dbo];
GO

-- a demo user will be created who is member of the [A-H] group
CREATE USER demo_user WITHOUT LOGIN;
ALTER ROLE [A-H] ADD MEMBER [demo_user];
GRANT SELECT, INSERT, UPDATE, DELETE ON demo.Customers TO [demo_user];
GRANT SELECT ON history.Customers TO [demo_user];
GO

-- now we add a new column to the demo.Customers for the group assignment
ALTER TABLE demo.Customers ADD [dbRole] CHAR(3) NULL;
ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = OFF);
GO

UPDATE	demo.Customers
SET		[dbRole] =	CASE
						WHEN Name < 'I' THEN 'A-H'
						WHEN Name >= 'I' AND Name < 'Q' THEN 'I-P'
						ELSE 'Q-Z'
					END
GO

ALTER TABLE demo.Customers
SET
(
	SYSTEM_VERSIONING = ON
	(HISTORY_TABLE = history.Customers)
);
GO

-- Check the tables!
SELECT * FROM demo.Customers;
GO

-- Now we create the row level security function
CREATE FUNCTION demo.fn_RowSelection(@dbRole CHAR(3))
RETURNS TABLE
WITH SCHEMABINDING
AS
RETURN
(
	SELECT	1	AS Result
	WHERE	IS_MEMBER(@dbRole) = 1
			OR IS_MEMBER('dbo') = 1
);
GO

-- Activate the security role
CREATE SECURITY POLICY CustomerFilter
ADD FILTER PREDICATE demo.fn_RowSelection([dbRole])   
ON demo.Customers
WITH (STATE = ON);

CREATE SECURITY POLICY historyCustomerFilter
ADD FILTER PREDICATE demo.fn_RowSelection([dbRole])   
ON history.Customers
WITH (STATE = ON);

EXECUTE AS USER = 'demo_user';
GO

-- Select the data!
SELECT * FROM demo.Customers;
GO

-- Update a record
UPDATE	demo.Customers
SET		Name = 'Quatschmacher AG',
		dbRole = 'Q-Z'
WHERE	Id = 5;
GO

SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL
WHERE Id = 5;
GO

SELECT * FROM history.Customers;
GO


REVERT;
GO

-- Now the admin changes a value!
UPDATE	demo.Customers
SET		Name = 'Xenon AG',
		dbRole = 'Q-Z'
WHERE	Id = 1;
GO

-- Now check what the demo_user can see in the history table
EXECUTE AS USER = 'demo_user';
GO

SELECT * FROM history.Customers;
GO

REVERT;
GO

-- Clean the kitchen!
DROP SECURITY POLICY CustomerFilter
DROP SECURITY POLICY historyCustomerFilter
GO

DROP USER demo_user;
GO

DROP ROLE [A-H];
DROP ROLE [I-P];
DROP ROLE [Q-Z];

EXEC dbo.sp_prepare_workbench
	@remove_all = 1;
