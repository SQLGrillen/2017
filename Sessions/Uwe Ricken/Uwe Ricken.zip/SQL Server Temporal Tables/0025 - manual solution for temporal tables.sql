/*============================================================================
	File:		0025 - manual solution for temporal tables.sql

	Summary:	This script demonstrates the requirements for tables in
				Microsoft SQL Server to become a system versioned temporal table 

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Temporal Tables - deep insides"

	Date:		October 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
GO

USE [CustomerOrders];
GO

-- Create the demo schema
IF SCHEMA_ID(N'demo') IS NULL
	EXEC sp_executesql N'CREATE SCHEMA [demo] AUTHORIZATION dbo;'
	GO

IF SCHEMA_ID(N'history') IS NULL
	EXEC sp_executesql N'CREATE SCHEMA [history] WITH AUTHORIZATION dbo;'
	GO

-- Create a demo table for the customers
IF OBJECT_ID(N'demo.Customers', N'U') IS NOT NULL
	DROP TABLE demo.Customers;
	GO

IF OBJECT_ID(N'history.Customers', N'U') IS NOT NULL
	DROP TABLE history.Customers;
	GO

SELECT	C.Id,
		C.Name,
		A.CCode,
		A.Street,
		A.ZIP,
		A.City,
		A.State,
		CAST(GETDATE() AS DATETIME2)	AS	ValidFrom,
		CAST('29991231' AS DATETIME2)	AS	ValidTo
INTO	demo.Customers
FROM	dbo.Customers AS C
		INNER JOIN dbo.CustomerAddresses AS CA
		ON C.Id = CA.Customer_Id
		INNER JOIN dbo.Addresses AS A
		ON (CA.Address_Id = A.Id)
WHERE	CA.IsDefault = 1;
GO

-- Now a PRIMARY KEY need to be created on the ID of the customers
ALTER TABLE demo.Customers
ADD CONSTRAINT pk_Customers_Id PRIMARY KEY CLUSTERED (Id);
GO

-- Now a history table will be created. It has to have the same
-- meta data structure than the "temporal table"
SELECT	*
INTO	history.Customers
FROM	demo.Customers
WHERE	1 = 0;
GO

-- A clustered index will be created for the datetime range
CREATE CLUSTERED INDEX cuix_Customers_ValidFrom
ON history.Customers
(
	ValidFrom,
	ValidTo
);
GO

-- If an existing record in demo.Customers will be updated
-- the "old" record need to be inserted into the history table
IF EXISTS (SELECT * FROM sys.triggers WHERE parent_id = OBJECT_ID(N'demo.Customers', N'U') AND name = N'trg_Customers_Update')
	DROP TRIGGER demo.trg_Customers_Update;
	GO

CREATE TRIGGER demo.trg_Customers_Update
ON demo.Customers
FOR UPDATE
AS
BEGIN
	SET NOCOUNT ON
	DECLARE	@Tran_Time DATETIME2;

	-- record the date when the transaction started!
	SELECT	@Tran_Time = ISNULL(DTDT.database_transaction_begin_time, GETDATE())
	FROM	sys.dm_tran_current_transaction AS DTCT
			INNER JOIN sys.dm_tran_database_transactions AS DTDT
			ON (DTCT.transaction_id = DTDT.transaction_id)
	WHERE	DTDT.database_id = DB_ID()
			AND DTDT.database_transaction_status = 1
			AND	DTDT.database_transaction_state = 4;

	-- Now we insert the "old" record in the history table with
	-- a ValidTo date which is the @Tran_Time
	INSERT INTO history.Customers
	(Id, Name, CCode, Street, ZIP, City, State, ValidFrom, ValidTo)
	SELECT	Id, Name, CCode, Street, ZIP, City, State, ValidFrom, @Tran_Time
	FROM	deleted AS D;

	-- Update the new records and set a ValidFrom to the
	-- transaction time
	UPDATE	C
	SET		C.ValidFrom = @Tran_Time
	FROM	demo.Customers AS C INNER JOIN inserted AS I
			ON (C.Id = I.Id);

	SET NOCOUNT OFF;
END
GO

-- If an existing record in demo.Customers will be deleted
-- the "old" record need to be inserted into the history table
IF EXISTS (SELECT * FROM sys.triggers WHERE parent_id = OBJECT_ID(N'demo.Customers', N'U') AND name = N'trg_Customers_Delete')
	DROP TRIGGER demo.trg_Customers_Delete;
	GO

CREATE TRIGGER demo.trg_Customers_Delete
ON demo.Customers
FOR DELETE
AS
BEGIN
	SET NOCOUNT ON
	DECLARE	@Tran_Time DATETIME2;

	-- record the date when the transaction started!
	SELECT	@Tran_Time = ISNULL(DTDT.database_transaction_begin_time, GETDATE())
	FROM	sys.dm_tran_current_transaction AS DTCT
			INNER JOIN sys.dm_tran_database_transactions AS DTDT
			ON (DTCT.transaction_id = DTDT.transaction_id)
	WHERE	DTDT.database_id = DB_ID()
			AND DTDT.database_transaction_status = 1
			AND	DTDT.database_transaction_state = 4;

	-- Now we insert the "old" record in the history table with
	-- a ValidTo date which is the @Tran_Time
	INSERT INTO history.Customers
	(Id, Name, CCode, Street, ZIP, City, State, ValidFrom, ValidTo)
	SELECT	Id, Name, CCode, Street, ZIP, City, State, ValidFrom, @Tran_Time
	FROM	deleted AS D;

	SET NOCOUNT OFF;
END
GO

/*
	-- RUN ALL SCRIPTS WITH THE DEBUGGER (F11)!
	-- DEMO-Script for UPDATE of a record
	BEGIN TRANSACTION;
	GO
		UPDATE	demo.Customers
		SET		Name = 'Uwe Ricken'
		WHERE	Id = 10;

	COMMIT TRANSACTION;
	GO

	-- DEMO-Script for DELETE of a record
	BEGIN TRANSACTION;
	GO
		DELETE	demo.Customers
		WHERE	Id = 10;

	COMMIT TRANSACTION;
	GO
*/

SELECT * FROM demo.Customers WHERE Id = 10;
GO
SELECT * FROM history.Customers WHERE Id = 10;
GO


-- clean the kitchen
IF OBJECT_ID(N'history.Customers', N'U') IS NOT NULL
	DROP TABLE history.Customers;
	GO

IF OBJECT_ID(N'demo.Customers', N'U') IS NOT NULL
	DROP TABLE demo.Customers;
	GO
