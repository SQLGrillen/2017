/*============================================================================
	File:		0100 - triggers in temporal tables.sql

	Summary:	This script demonstrates all different situations when
				an object in a temporal relationship will be renamed:
				- System Versioned Temporal Table
				- History Table
				- Column Name

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- create demo environment with data
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
    @fill_data = 1,
    @remove_all = 0;
GO

-- now the table will get another column for the storage of
-- the actual user who updated the record
IF NOT EXISTS
(
	SELECT * FROM sys.columns
	WHERE	OBJECT_ID = OBJECT_ID(N'demo.Customers', N'U')
			AND name = 'InsertUser'
)
	ALTER TABLE demo.Customers ADD [InsertUser] sysname NULL;
	GO

-- check the available columns in the demo.Customers table!
SELECT	*
FROM	sys.columns
WHERE	OBJECT_ID = OBJECT_ID(N'demo.Customers', N'U')
ORDER BY
		column_id;

-- now let's create a trigger which track the user name who changed
-- the record
IF OBJECT_ID(N'demo.trg_Customers_Update', N'TR') IS NOT NULL
	DROP TRIGGER demo.trg_Customers_Update;
	GO

CREATE TRIGGER demo.trg_Customers_Update
ON demo.Customers
FOR UPDATE
AS
	SET NOCOUNT ON;

	UPDATE	C
	SET		InsertUser = ORIGINAL_LOGIN()
	FROM	demo.Customers AS C INNER JOIN inserted AS I
			ON (C.Id = I.Id);

	SET NOCOUNT OFF;
GO

-- Let's play with the data...
SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL AS C
WHERE C.Id = 10;
GO

UPDATE demo.Customers
SET		Name = 'db Berater GmbH'
WHERE	Id = 10;
GO

-- How many records do you expect in the result set?
SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL AS C
WHERE C.Id = 10;
GO

-- ... and how many records do we have in the history?
SELECT * FROM history.Customers
WHERE	Id = 10;
GO

-- repeat the steps in slow motion (we have enough time :) )
UPDATE demo.Customers
SET		Name = 'SQLBits UK'
WHERE	Id = 20;
GO

-- clean the kitchen!
EXEC dbo.sp_prepare_workbench
	@remove_all = 1;
GO