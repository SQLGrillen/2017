/*============================================================================
	File:		0050 - querying temporal tables.sql

	Summary:	This script shows different ways 

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Temporal Tables - deep insides"

	Info:		Handling the indexes of temporal table is a complex topic.
				Izik Ben-Gan has written a remarkable blog post about it here:
				http://sqlmag.com/sql-server/first-look-system-versioned-temporal-tables-part-2-querying-data-and-optimization-conside

	Date:		October 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- IMPORTANT: All examples require the previous start of the script
-- 0020 - background update process for dbo.employees.sql

-- Show ALL data changes for a specific employee
SELECT * FROM dbo.Employees
FOR SYSTEM_TIME ALL AS E
WHERE	E.Id = 99
ORDER BY
		E.ValidFrom
OPTION	(QUERYTRACEON 9130);
GO

-- Original made by Microsoft !!!
CREATE CLUSTERED INDEX cix_history_Employees
ON history.Employees
(
	ValidTo,
	ValidFrom
);
GO

-- use TF 9130 for visibility of residual predicate(s)
SELECT * FROM dbo.Employees FOR SYSTEM_TIME ALL AS E
WHERE	E.Id = 99
ORDER BY
		E.ValidFrom
OPTION	(QUERYTRACEON 9130);
GO

-- Try to optimize history.Employees
CREATE CLUSTERED INDEX cix_history_Employees
ON history.Employees
(
	Id,
	ValidFrom,
	ValidTo	
) WITH DROP_EXISTING;
GO

SELECT * FROM dbo.Employees WHERE Id = 99;
SELECT * FROM history.Employees WHERE Id = 99;
GO

-- Show the record as it was valid 30 mins ago!
-- use RECOMPILE to use the histogram!
DECLARE	@ValidDate	DATETIME2(0) = DATEADD(MINUTE, -30, GETUTCDATE());
SELECT * FROM dbo.Employees
FOR SYSTEM_TIME AS OF @ValidDate AS E
WHERE	E.Id = 99
OPTION	(RECOMPILE);
GO

-- Show record changes in a time range
DECLARE @StartDate	DATETIME2(0) = DATEADD(MINUTE, -30, GETUTCDATE());
DECLARE @EndDate	DATETIME2(0) = DATEADD(MINUTE, -10, GETUTCDATE());
SELECT * FROM dbo.Employees
FOR SYSTEM_TIME FROM @StartDate TO @EndDate AS E
WHERE	Id = 99
ORDER BY ValidFrom
OPTION	(RECOMPILE);
GO

-- Show records changes between a time range
DECLARE @StartDate	DATETIME2(0) = DATEADD(MINUTE, -30, GETUTCDATE());
DECLARE @EndDate	DATETIME2(0) = DATEADD(MINUTE, -10, GETUTCDATE());
SELECT * FROM dbo.Employees FOR SYSTEM_TIME BETWEEN @StartDate AND @EndDate AS E
ORDER BY ValidFrom
OPTION	(RECOMPILE);
GO

-- Show records changes CONTAINED in a time range
DECLARE @StartDate	DATETIME2(0) = DATEADD(MINUTE, -30, GETUTCDATE());
DECLARE @EndDate	DATETIME2(0) = DATEADD(MINUTE, -10, GETUTCDATE());
SELECT * FROM dbo.Employees FOR SYSTEM_TIME CONTAINED IN (@StartDate, @EndDate) AS E
ORDER BY ValidFrom
OPTION	(RECOMPILE);
GO