/*============================================================================
	File:		0170 - temporal tables in long running transactions.sql

	Summary:	This script creates a stored procedure for the default
				preparation of the workbench for the demos.
				It creates two schemas and - based on the para

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
	@fill_data = 1;
GO

BEGIN TRANSACTION;
GO
	-- simulate a looooong running transaction
	-- which runs an update on a temporal table
	-- at the end
	SELECT	DTAT.transaction_id,
			DTAT.name,
			DTAT.transaction_begin_time
	FROM	sys.dm_tran_current_transaction AS DTCT
			INNER JOIN sys.dm_tran_active_transactions AS DTAT
			ON (DTCT.transaction_id = DTAT.transaction_id);
	GO

	RAISERROR (N'Now the looooong transaction starts! Hurry up with the second statement...', 0, 1) WITH NOWAIT;
	WAITFOR DELAY '00:00:10'
	GO

	UPDATE	demo.Customers
	SET		name = 'Uwe Ricken'
	WHERE	Id = 10;
	GO
COMMIT TRANSACTION;
GO

/*
	Now go with the following statement AFTER the execution of
	the first transaction into a new SSMS-window and execute 
	the statement!

USE CustomerOrders;
GO

BEGIN TRANSACTION;
GO
	SELECT	DTAT.transaction_id,
			DTAT.name,
			DTAT.transaction_begin_time
	FROM	sys.dm_tran_current_transaction AS DTCT
			INNER JOIN sys.dm_tran_active_transactions AS DTAT
			ON (DTCT.transaction_id = DTAT.transaction_id);
	GO

	UPDATE	demo.Customers
	SET		name = 'Beate Ricken'
	WHERE	Id = 10;
	GO
COMMIT TRANSACTION;
GO
*/