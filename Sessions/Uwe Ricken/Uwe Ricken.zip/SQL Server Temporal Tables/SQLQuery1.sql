/*============================================================================
	File:		0150 - temporal tables and calculated columns.sql

	Summary:	This script is part of the "temporal tables" session and
				demonstrates the behavior of row level security in conjunction
				with System Versioned Temporal Tables

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- prepare the table for temporal table environment
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
	@fill_data = 0;
GO

ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = OFF);
GO

ALTER TABLE demo.Customers
ADD [Address] AS ([ZIP] + ' ' + [City]);
GO

ALTER TABLE history.Customers
ALTER COLUMN [Address] VARCHAR(106) NOT NULL;
GO

ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = ON (HISTORY_TABLE = history.Customers));
GO
