------------------------------------------------------------------------------------------
-- USE THE SCRIPT TO REPLICATE THE SECENARIO dbo.Employee AND IT IS SYSTEM VERSIONED WITH 
-- CUSTOM NAME dbo.EmployeeHistory.
------------------------------------------------------------------------------------------
-- STEPS TO REPLICATE THE ISSUE
-- STEP 01 :: CREATE THE TABLE dbo.Employee and dbo.EmployeeHistory
-- STEP 02 :: INSERT A ROW INTO THE TABLE
-- STEP 03 :: OPEN TWO SSMS SESSIONS THAT CONNECTS TO THE DATABASE WHERE THE NEW TABLE IS CREATED.
-- STEP 04 :: COPY and PASTE THE TRANSACTION T1 AND T2 INTO SESSION 1 AND 2 RESPECTIVELY
-- STEP 05 :: EXECUTE SESSION 1 AND THEN SESSION 2 ONE AFTER ANOTHER. WILL GET THE ISSUE AT SESSION 1
------------------------------------------------------------------------------------------

-- STEP 01
USE [TESTDB]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER TABLE dbo.Employee SET (SYSTEM_VERSIONING = OFF);
DROP TABLE dbo.EmployeeHistory
DROP TABLE dbo.Employee;
GO

CREATE TABLE [dbo].[Employee]
(
[EmployeeID] [INT] IDENTITY(1, 1) NOT NULL,
[Name] [NVARCHAR](100) NOT NULL,
[Position] [VARCHAR](100) NOT NULL,
[Department] [VARCHAR](100) NOT NULL,
[Address] [NVARCHAR](1024) NOT NULL,
[AnnualSalary] [DECIMAL](10, 2)  NULL,
[ValidFrom] [DATETIME2](2) GENERATED ALWAYS AS ROW START NOT NULL,
[ValidTo] [DATETIME2](2) GENERATED ALWAYS AS ROW END NOT NULL,
PRIMARY KEY CLUSTERED 
(
[EmployeeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
PERIOD FOR SYSTEM_TIME ([ValidFrom], [ValidTo])
) ON [PRIMARY]
WITH
(
SYSTEM_VERSIONING = ON ( HISTORY_TABLE = [dbo].[EmployeeHistory] )
)
GO
------------------------------------------------------------------------------------------

-- STEP 02
INSERT INTO dbo.Employee
(
[Name],
[Position],
[Department],
[Address]
)
VALUES
(
N'John Smith',
'COO',
'Sales',
N'Department of State, 2430 Nouakchott Place, Washington, DC 20521-2430'
)
------------------------------------------------------------------------------------------

-- STEP 04 -- COPY TO SSMS SESSION 1
BEGIN TRANSACTION T1
-- Here I'm using wait to simulate as certain pre-processing in our business scenario
WAITFOR DELAY '00:00:30'

UPDATE dbo.Employee
SET [Position] = 'CTO'
WHERE EmployeeID = 1
COMMIT TRAN T1

-- STEP 04 -- COPY TO SSMS SESSION 2
BEGIN TRANSACTION T2
UPDATE dbo.Employee
SET [Department] = 'Development'
WHERE EmployeeID = 1
COMMIT TRAN T2
