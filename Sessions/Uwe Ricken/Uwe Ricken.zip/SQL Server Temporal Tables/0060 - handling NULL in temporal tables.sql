/*============================================================================
	File:		0060 - handling NULL in temporal tables.sql

	Summary:	This script demonstrates the different behaviors of temporal
				tables when meta data information will be changed!

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Temporal Tables - deep insides"

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- prepare the demo environment without new data!
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
    @fill_data = 0,
    @remove_all = 0;

-- 1. Demo: NULL becomes NOT NULL in an empty table
BEGIN TRANSACTION;
GO
	ALTER TABLE demo.Customers
	ALTER COLUMN [Phone] VARCHAR(20) NOT NULL;
	GO

	SELECT	SCHEMA_NAME(o.schema_id) + N'.' + O.name,
			DTL.request_mode,
			DTL.request_type,
			DTL.request_status
	FROM	sys.dm_tran_locks AS DTL
			INNER JOIN sys.objects AS O
			ON (DTL.resource_associated_entity_id = O.object_id)
	WHERE	DTL.request_session_id = @@SPID
			AND DTL.resource_type = N'OBJECT'
	GO

COMMIT TRANSACTION;
GO

-- 2. Demo: NULL becomes NOT NULL in a table with existing data
INSERT INTO [demo].[Customers]
(Name, Street, ZIP, City, Phone, EMail)
VALUES
(
	'db Berater GmbH', 'Bahnstrasse 33', '64390', 'Erzhausen',
	'06150-1234567', 'info@db-berater.de'
);
GO

ALTER TABLE demo.Customers
ALTER COLUMN [EMail] VARCHAR(255) NOT NULL;
GO

-- 3. Demo: NOT NULL becomes NULL in a table with existing data
ALTER TABLE demo.Customers
ALTER COLUMN [EMail] VARCHAR(100) NULL;
GO

-- what happens if a NULLable column in the temporary table has NULL-values?
INSERT INTO [demo].[Customers]
(Name, Street, ZIP, City, Phone, EMail)
VALUES
(
	'Microsoft Deutschland GmbH', 'Walter-Gropius-Stra�e 5',
	'80807', 'M�nchen', '0180-6672255', NULL
);
GO

SELECT * FROM demo.Customers;
GO

ALTER TABLE demo.Customers
ALTER COLUMN [EMail] VARCHAR(100) NOT NULL;
GO

UPDATE	demo.Customers
SET		EMail = 'info@de.microsoft.com'
WHERE	Id = 2;
GO

ALTER TABLE demo.Customers
ALTER COLUMN [EMail] VARCHAR(100) NOT NULL;
GO

-- Clean the kitchen
EXEC dbo.sp_prepare_workbench
    @remove_all = 1;
GO
