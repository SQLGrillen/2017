/*============================================================================
	File:		0030 - requirements for temporal tables.sql

	Summary:	This script demonstrates the requirements for tables in
				Microsoft SQL Server to become a system versioned temporal table 

				THIS SCRIPT IS PART OF THE TRACK: "SQL Server Temporal Tables - deep insides"

	Date:		October 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET NOCOUNT ON;
SET LANGUAGE us_english;
GO

USE CustomerOrders;
GO

-- As there is no schema history in the database it will be created first!
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = N'history')
	EXEC sp_executesql N'CREATE SCHEMA [history] AUTHORIZATION dbo;';
GO

IF OBJECT_ID('history.Addresses', N'U') IS NOT NULL
	DROP TABLE history.Addresses;
	GO

CREATE TABLE history.Addresses
(
	Id		int				NOT NULL,
	Street	varchar(200)	NOT NULL,
	CCode	char(3)			NOT NULL,
	ZIP		char(10)		NOT NULL,
	City	varchar(200)	NOT NULL,
	State	varchar(200)	NOT NULL
)
GO

-- 1 Try to implement Temporary Tables
ALTER TABLE dbo.Addresses
SET
	(
		SYSTEM_VERSIONING = ON
		(HISTORY_TABLE = History.Addresses)
	);
GO

-- ok - define the system period time for dbo.Addresses
ALTER TABLE dbo.Addresses
ADD
	StartTime datetime2(0) GENERATED ALWAYS AS ROW START
	CONSTRAINT df_AddressesStartTime DEFAULT ('2016-01-01 00:00'),
	EndTime datetime2(0) GENERATED ALWAYS AS ROW END
	CONSTRAINT df_AddressesEndTime DEFAULT (CONVERT(datetime2(0), '9999-12-31 23:59:59')),
	PERIOD FOR SYSTEM_TIME (StartTime, EndTime);
GO

-- 2 Try to implement Temporary Tables
ALTER TABLE dbo.Addresses
SET
	(
		SYSTEM_VERSIONING = ON
		(HISTORY_TABLE = History.Addresses)
	);
GO

-- ok - let's create a PRIMARY KEY
ALTER TABLE dbo.Addresses ADD CONSTRAINT pk_Addresses
PRIMARY KEY CLUSTERED (Id);
GO

-- 3 Try to implement Temporary Tables
ALTER TABLE dbo.Addresses
SET
	(
		SYSTEM_VERSIONING = ON
		(HISTORY_TABLE = History.Addresses)
	);
GO

ALTER TABLE history.Addresses
ADD
	StartTime	datetime2(0) NOT NULL,
	EndTime		datetime2(0) NOT NULL;
GO

-- 4 Try to implement Temporary Tables
ALTER TABLE dbo.Addresses
SET
	(
		SYSTEM_VERSIONING = ON
		(HISTORY_TABLE = History.Addresses)
	);
GO

SELECT * FROM dbo.Addresses;
GO

UPDATE	dbo.Addresses
SET		CCode = 'DE'
WHERE	Id = 2;
GO

UPDATE	dbo.Addresses
SET		Street = 'Bahnstrasse 33'
WHERE	Id = 1;
GO

DELETE	dbo.Addresses WHERE Id = 1;
GO

SELECT * FROM history.Addresses
WHERE	Id = 2;
GO

SELECT * FROM dbo.Addresses
WHERE	Id IN (1, 2);

DELETE history.Addresses;


-- YEAH!!! - finally it works.
ALTER TABLE dbo.Addresses SET (SYSTEM_VERSIONING = OFF);
ALTER TABLE dbo.Addresses DROP PERIOD FOR SYSTEM_TIME;
ALTER TABLE dbo.Addresses DROP CONSTRAINT pk_Addresses;
ALTER TABLE dbo.Addresses DROP CONSTRAINT df_AddressesStartTime;
ALTER TABLE dbo.Addresses DROP CONSTRAINT df_AddressesEndTime;
ALTER TABLE dbo.Addresses DROP COLUMN [StartTime];
ALTER TABLE dbo.Addresses DROP COLUMN [EndTime];
GO

DROP TABLE history.Addresses;
GO

