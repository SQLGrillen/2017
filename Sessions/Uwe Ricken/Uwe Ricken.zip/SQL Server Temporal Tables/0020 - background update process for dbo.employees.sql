/*============================================================================
	File:		0020 - background update process for dbo.employees.sql

	Summary:	This script uses the existing database CustomerOrders and
				makes the table dbo.Employees a system versioned table.
				When system versioning is activated it runs a random update
				every 10 seconds on a different column of the table for
				demonstration purposes.

	Date:		October 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
USE CustomerOrders;
GO

-- this script will run in the background of the session
-- and will be used for demonstration of querying 
-- temporal objects!
RAISERROR (N'Deleting constraints and not necessary columns from dbo.Employees', 0, 1) WITH NOWAIT;
IF EXISTS
(
	SELECT * FROM sys.default_constraints AS DC
	WHERE	DC.parent_object_id = OBJECT_ID(N'dbo.Employees', N'U')
			AND DC.name = N'DF__Employees__Inser__117F9D94'
)
BEGIN
	ALTER TABLE dbo.Employees DROP CONSTRAINT DF__Employees__Inser__117F9D94;
	ALTER TABLE dbo.Employees DROP COLUMN InsertDate;
END
GO

-- Prepare the table dbo.Employees for system versioned temporal tables
RAISERROR (N'Creating a PRIMARY KEY constraint on dbo.Employees...', 0, 1) WITH NOWAIT;
IF NOT EXISTS
(
	SELECT	* FROM sys.objects
	WHERE	parent_object_id = OBJECT_ID(N'dbo.Employees', N'U')
			AND type_desc = 'PRIMARY_KEY_CONSTRAINT'
)
	ALTER TABLE dbo.Employees
	ADD CONSTRAINT pk_Employees_Id PRIMARY KEY CLUSTERED (Id);
	GO

-- add two new columns to the table for the storage
-- of the datetime
RAISERROR(N'Adding system controlled row versioning columns to dbo.Employees...', 0, 1) WITH NOWAIT;
IF NOT EXISTS
(
	SELECT	Name
	FROM	sys.columns AS C
	WHERE	c.object_id = OBJECT_ID(N'dbo.Employees', N'U')
			AND name = N'ValidFrom'
)
	ALTER TABLE dbo.Employees
	ADD
		ValidFrom	DATETIME2(0) GENERATED ALWAYS AS ROW START
		CONSTRAINT df_Employees_ValidFrom DEFAULT ('2016-01-01 00:00:00'),
		ValidTo		DATETIME2(0) GENERATED ALWAYS AS ROW END
		CONSTRAINT df_Employees_ValidTo DEFAULT (CONVERT(datetime2(0), '9999-12-31 23:59:59')),
		PERIOD FOR SYSTEM_TIME (ValidFrom, ValidTo);
GO

-- Create a history table in the history schema
RAISERROR (N'Creating the history table in the [history]-schema...', 0, 1) WITH NOWAIT;
IF SCHEMA_ID(N'history') IS NULL
	EXEC sp_executesql N'CREATE SCHEMA history AUTHORIZATION dbo;';
	GO

IF EXISTS
(
	SELECT * FROM sys.tables AS T
	WHERE	T.object_id = OBJECT_ID(N'history.Employees')
			AND T.temporal_type = 1
)
	ALTER TABLE dbo.Employees SET (SYSTEM_VERSIONING = OFF);
GO

IF OBJECT_ID(N'history.Employees', N'U') IS NOT NULL
	DROP TABLE history.Employees;
	GO

CREATE TABLE history.Employees
(
	Id				INT				NOT NULL,
	FirstName		VARCHAR(200)	NOT NULL,
	LastName		VARCHAR(200)	NOT NULL,
	EMailAddress	VARCHAR(255)	NOT NULL,
	HireDate		DATE			NOT NULL,
	ACTIVE			BIT				NOT NULL,
	InsertUser		SYSNAME			NOT NULL,
	ValidFrom		DATETIME2(0)	NOT NULL,
	ValidTo			DATETIME2(0)	NOT NULL
);
GO

-- When the prerequisites have been done the Temporal Table implementation can be done!
RAISERROR (N'Setting dbo.Employees to system versioned temporal table administration...', 0, 1) WITH NOWAIT;
IF EXISTS
(
	SELECT	*
	FROM	sys.tables
	WHERE	OBJECT_ID = OBJECT_ID(N'dbo.Employees', N'U')
			AND temporal_type = 0
)
ALTER TABLE dbo.Employees
SET
	(
		SYSTEM_VERSIONING = ON
		(HISTORY_TABLE = History.Employees)
	);
GO

-- Now we can start the changing process of the data
SET NOCOUNT ON;
GO

DECLARE @commandlist TABLE
(
	Id		INT				NOT NULL PRIMARY KEY,
	Command	NVARCHAR(1000)	NOT NULL
);


INSERT INTO @CommandList
VALUES
(1, N'UPDATE dbo.Employees SET FirstName = newid() WHERE Id = @ID;'),
(2, N'UPDATE dbo.Employees SET LastName = newid() WHERE Id = @ID;'),
(3, N'UPDATE dbo.Employees SET HireDate = DATEADD(DAY, CAST(RAND() * 365 AS INT) * -1, GETDATE()) WHERE ID = @Id;'),
(4, N'UPDATE dbo.Employees SET EMailAddress = ''funnyaddress@gmail.com'' WHERE Id = @Id;'),
(5, N'UPDATE dbo.Employees SET InsertUser = ''Buggs Bunny'' WHERE Id = @ID;'),
(6, N'UPDATE dbo.Employees SET Active = CASE WHEN ACTIVE = 0 THEN 1 ELSE 0 END WHERE Id = @ID;'),
(7, N'DELETE dbo.Employees WHERE Id = @Id;');
 
-- Now we update the records in a random way
DECLARE @stmt	NVARCHAR(1000);
DECLARE @Command_Id INT = CAST(RAND() * 6 AS INT) + 1;
DECLARE	@Employee_Id INT = CAST(RAND() * 150 AS INT) + 1;
WHILE (1 = 1)
BEGIN
	SELECT	@stmt = C.Command
	FROM	@commandlist AS C
	WHERE	C.Id = @Command_Id;

	RAISERROR (N'Update/Delete of record [%i]...', 1, 0, @Employee_Id) WITH NOWAIT;
	EXEC sp_executesql @stmt, N'@Id INT', @Employee_Id;
	WAITFOR DELAY '00:00:10';

	SET	@Command_Id		= CAST(RAND() * 7 AS INT) + 1;
	SET	@Employee_Id	= CAST(RAND() * 150 AS INT) + 1;
END
GO