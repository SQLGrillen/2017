/*============================================================================
	File:		0180 - INSTEAD OF TRIGGERS in temporal tables.sql

	Summary:	This script demonstrates all different situations when
				an object in a temporal relationship will be renamed:
				- System Versioned Temporal Table
				- History Table
				- Column Name

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
    @fill_data = 1,
    @remove_all = 0;
GO

-- Let's add a new column for the name of the user
IF NOT EXISTS
(
	SELECT	C.column_id
	FROM	sys.columns AS C
	WHERE	OBJECT_ID = OBJECT_ID(N'demo.Customers', N'U')
			AND C.name = N'UserName'
)
ALTER TABLE demo.Customers
ADD [UserName] sysname NOT NULL
CONSTRAINT df_Customers_UserName DEFAULT N'Donald Duck';
GO

-- Now we try to create an INSTEAD_OF UPDATE-trigger
-- to update the UserName-column when a record will be
-- updated
IF OBJECT_ID(N'demo.tr_Customers_Update', N'TR') IS NOT NULL
	DROP TRIGGER demo.tr_Customers_Update;
	GO

CREATE TRIGGER demo.tr_Customers_Update
ON demo.Customers
INSTEAD OF UPDATE
AS
	SET NOCOUNT ON;

	UPDATE	C
	SET		C.Name		=	I.Name,
			C.Street	=	I.Street,
			C.ZIP		=	I.ZIP,
			C.City		=	I.City,
			C.Phone		=	I.Phone,
			C.EMail		=	I.EMail,
			C.UserName	=	ORIGINAL_LOGIN()
	FROM	demo.Customers AS C
			INNER JOIN inserted AS I
			ON (C.Id = I.Id)

	SET NOCOUNT OFF;
GO

-- because it is not allowed to have INSTEAD OF-triggers on
-- tables we try it with a view :)
IF OBJECT_ID(N'demo.v_Customers', N'V') IS NOT NULL
	DROP VIEW demo.v_Customers;
	GO

CREATE VIEW demo.v_Customers
AS
	SELECT	Id,
			Name,
			Street,
			ZIP,
			City,
			Phone,
			EMail,
			ValidFrom,
			ValidTo
			UserName
	FROM	demo.Customers;
GO

IF OBJECT_ID(N'demo.tr_Customers_Update', N'TR') IS NOT NULL
	DROP TRIGGER demo.tr_Customers_Update;
	GO

CREATE TRIGGER demo.tr_Customers_Update
ON demo.v_Customers
INSTEAD OF UPDATE
AS
	SET NOCOUNT ON;

	UPDATE	C
	SET		C.Name		=	I.Name,
			C.Street	=	I.Street,
			C.ZIP		=	I.ZIP,
			C.City		=	I.City,
			C.Phone		=	I.Phone,
			C.EMail		=	I.EMail,
			C.UserName	=	ORIGINAL_LOGIN()
	FROM	demo.Customers AS C
			INNER JOIN inserted AS I
			ON (C.Id = I.Id)

	SET NOCOUNT OFF;
GO

SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL
WHERE	Id = 10;
GO

UPDATE	demo.v_Customers
SET		Name = 'db Berater GmbH'
WHERE	Id = 10;
GO

SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL
WHERE	Id = 10;
GO
