/*============================================================================
	File:		0080 - changing data types in temporal tables.sql

	Summary:	This script demonstrates the handling of temporal tables
				when data types will be changed.

	Date:		November 2016

	SQL Server Version: 2016
------------------------------------------------------------------------------
	Written by Uwe Ricken, db Berater GmbH

	This script is intended only as a supplement to demos and lectures
	given by Uwe Ricken.  
  
	THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
	ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
	TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
	PARTICULAR PURPOSE.
============================================================================*/
SET LANGUAGE us_english;
SET NOCOUNT ON;
GO

USE CustomerOrders;
GO

-- A customer table with temporal table will be created
-- The question here is whether a column which is NULLABLE can be changed
-- afterwards to NON NULLABLE

-- prepare the workbench!
EXEC dbo.sp_prepare_workbench
	@create_tables = 1,
	@fill_data = 1;
	GO

--  get an overview from the columns in demo table!
SELECT	C.name,
		T.name			AS	data_type,
		C.max_length,
		C.collation_name
FROM	sys.columns AS C INNER JOIN sys.types AS T
		ON
		(
			c.system_type_id = T.system_type_id
			AND c.user_type_id = T.user_type_id
		)
WHERE	C.object_id = OBJECT_ID(N'demo.Customers', N'U')
ORDER BY
		C.column_id;

GO

-- What is the max length for a company name and for a street name?
SELECT	MAX(DATALENGTH(name))	AS	company_name,
		MAX(DATALENGTH(Street))	AS	street_name
FROM	demo.Customers;
GO

/*
	Company Name:	39
	Street:			35
*/

-- reduce the data length from name from 100 characters to 50 characters
ALTER TABLE demo.Customers
ALTER COLUMN [name] VARCHAR(50) NOT NULL;
GO

-- reduce the data lenght from street from 100 characters to 30 characters
ALTER TABLE demo.Customers
ALTER COLUMN [Street] VARCHAR(30) NOT NULL;
GO

-- first add a new entry into the history table!
UPDATE	demo.Customers
SET		Street = REPLICATE('A', 60)
WHERE	Id = 10;
GO

-- what is now in the history table?
SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL  AS C
WHERE	C.Id = 10;
GO

-- now we reduce the street name back to 30 characters for ALL records
UPDATE	demo.Customers
SET		Street = REPLICATE('A', 30);
GO

-- and now we try to reduce the length from 100 to 35 characters!
ALTER TABLE demo.Customers
ALTER COLUMN [Street] VARCHAR(30) NOT NULL;
GO

-- release the system versioning to check whether it is the history table
ALTER TABLE demo.Customers SET (SYSTEM_VERSIONING = OFF)
GO

ALTER TABLE demo.Customers
ALTER COLUMN [Street] VARCHAR(30) NOT NULL;
GO

-- release the system versioning to check whether it is the history table
ALTER TABLE demo.Customers
SET
(
	SYSTEM_VERSIONING = ON
	(HISTORY_TABLE = history.Customers)	
);
GO

-- reduce the length of the characters
UPDATE	history.Customers WITH (TABLOCK)
SET		Street = LEFT(Street, 30);
GO

ALTER TABLE history.Customers
ALTER COLUMN [Street] VARCHAR(30) NOT NULL;
GO

ALTER TABLE demo.Customers
SET
(
	SYSTEM_VERSIONING = ON
	(HISTORY_TABLE = history.Customers)	
);
GO

SELECT * FROM demo.Customers
FOR SYSTEM_TIME ALL AS C
WHERE	C.Id = 10;
GO

-- Clean the kitchen!
EXEC dbo.sp_prepare_workbench
	@create_tables = 0;
	GO